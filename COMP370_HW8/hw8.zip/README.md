## McGill Ontology:
- Academia
- Administration
- Events & Fun
- Discussion
- Campus
- Technical issues
- Personal experiences


## Concordia Ontolofy:
- Coursework
- Program
- Campus Life
- Admissions
- Career
- Financial & Administrative Affairs
- Community
- Technical